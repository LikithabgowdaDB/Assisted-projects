package com.ecommerce;


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBConnection {

	static Connection con;
	public static Connection getConnection() {
		try {
		//Step 1: load driver in memory
		Class.forName("com.mysql.cj.jdbc.Driver");
		//Step 2: Connection with database
		con=(Connection) DriverManager.getConnection("jdbc:mysql://localhost:3306/ecommerce","root","Likitha@123#21");
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		return con;
	}
}