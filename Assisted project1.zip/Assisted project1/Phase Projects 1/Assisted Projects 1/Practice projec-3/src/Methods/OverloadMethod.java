package Methods;

public class OverloadMethod {
	
public void area(int s,int t) {
	
	System.out.println("Area of Triangle:"+(0.5*s*t));
}
	
	public void area(int y) {
		 
		System.out.println("Area of Circle:"+(3.14*y*y));
		
	}
	public static void main(String[] args) {
		OverloadMethod obj = new OverloadMethod();
		obj.area(5);
		obj.area(12,14);
}
}

