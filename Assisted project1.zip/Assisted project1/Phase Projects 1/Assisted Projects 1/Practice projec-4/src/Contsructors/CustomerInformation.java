
package Contsructors;

public class CustomerInformation {
	int id;
	String name;
	void display() {
		System.out.println(id + " ;" + name);
	}
	
public static void main(String[] args) {
	
	CustomerInformation cust = new CustomerInformation();
	
	CustomerInformation cust1 = new CustomerInformation();
	
	cust.display();
	
	cust1.display();
}
}
