/**
 * 
 */
/**
 * 
 */
module Array_assisted {
}