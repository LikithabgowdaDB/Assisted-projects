package ImplemenrationOfMaps;

import java.util.*;

public class ImpofMaps {

		public static void main(String[] args) {			
			//Hash map
			HashMap<Integer,String> hm=new HashMap<Integer,String>();      
		      hm.put(1,"Likitha");    
		      hm.put(2,"Vandana");    
		      hm.put(3,"Priya");   
		       
		      System.out.println("\nThe elements of Hashmap are ");  
		      for(Map.Entry <Integer,String> m:hm.entrySet()){ 
		       System.out.println(m.getKey()+" "+m.getValue());    
		      }
		      
		     //Hash Table 
		      Hashtable<Integer,String> ht=new Hashtable<Integer,String>();  
		      
		      ht.put(4,"Rachana");  
		      ht.put(5,"Neelu");  
		      ht.put(6,"Pooja");  
		      ht.put(7,"Sindhu");  

		      System.out.println("\nThe elements of HashTable are ");  
		      for(Map.Entry <Integer,String> n:ht.entrySet()){    
		       System.out.println(n.getKey()+" "+n.getValue());    
		      }
		      
		      //Tree Map
		      TreeMap<Integer,String> map=new TreeMap<Integer,String>();    
		      map.put(8,"Ruchith");    
		      map.put(9,"Shalini");    
		      map.put(10,"Bhoomika");       
		      
		      System.out.println("\nThe elements of TreeMap are ");  
		      for(Map.Entry <Integer,String> l:map.entrySet()){    
		       System.out.println(l.getKey()+" "+l.getValue());    
		     }    
		      
		  }  
}

