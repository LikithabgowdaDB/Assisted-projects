package practicee;

public class Typecasting {
	public static void main(String[] args) {
		
		//implicit conversion
		System.out.println("Implicit of the type casting");
		 char s='S';
		System.out.println("value of s:" +s);
		
		int a=s;
		System.out.println("value of a:" +a);
		
		float g='d';
		System.out.println("value of g:" +g);
		
		long r='g';
		System.out.println("value of r:" +r);
		
		double i='k';
		System.out.println("value of i:" +i);
		
		System.out.println("\n");
		
		System.out.println("Explicit type casting");
		
		//explicit conversation
		double y=85;
		int z=(int)y;
		System.out.println("value of y:" +y);
		System.out.println("value of z:" +z);
		
	}
}

