package Acess_modifier;

public class private_acess_specifier {
	void display() 
    { 
        System.out.println("Using private access specifier"); 
    } 
	public static void main(String[] args) {
		System.out.println("Private Access Specifier");
		private_acess_specifier obj = new private_acess_specifier();
		 obj.display();

	}

}
