package Acess_modifier;

public class default_acess_modifier {
	void display() 
	   { 
	       System.out.println("Using defalut access specifier"); 
	   } 
	public static void main(String[] args) {
		System.out.println("Dafault Access Specifier");
		default_acess_modifier obj = new default_acess_modifier(); 		  
        obj.display();

	}

}
